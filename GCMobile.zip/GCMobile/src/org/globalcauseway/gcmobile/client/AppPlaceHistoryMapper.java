/*
 * Copyright 2010 Daniel Kurka
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.globalcauseway.gcmobile.client;

import org.globalcauseway.gcmobile.client.activities.AboutPlace.AboutPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.UIPlace.UIPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animation.AnimationPlace.AnimationPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationCubePlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationDissolvePlace.AnimationDissolvePlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationFadePlace.AnimationFadePlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationFlipPlace.AnimationFlipPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationPopPlace.AnimationPopPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSlidePlace.AnimationSlidePlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSlideUpPlace.AnimationSlideUpPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSwapPlace.AnimationSwapPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.button.ButtonPlace.ButtonPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.buttonbar.ButtonBarPlace.ButtonBarPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.carousel.CarouselPlace;
import org.globalcauseway.gcmobile.client.activities.elements.ElementsPlace.ElementsPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.forms.FormsPlace;
import org.globalcauseway.gcmobile.client.activities.gcell.GroupedCellListPlace;
import org.globalcauseway.gcmobile.client.activities.popup.PopupPlace.PopupPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.progressbar.ProgressBarPlace.ProgressBarPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.progressindicator.ProgressIndicatorPlace;
import org.globalcauseway.gcmobile.client.activities.pulltorefresh.PullToRefreshPlace;
import org.globalcauseway.gcmobile.client.activities.scrollwidget.ScrollWidgetPlace.ScrollWidgetPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.searchbox.SearchBoxPlace.SearchBoxPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.slider.SliderPlace.SliderPlaceTokenizer;
import org.globalcauseway.gcmobile.client.activities.tabbar.TabBarPlace.TabBarPlaceTokenizer;
import org.globalcauseway.gcmobile.client.places.HomePlace.HomePlaceTokenizer;

import com.google.gwt.place.shared.PlaceHistoryMapper;
import com.google.gwt.place.shared.WithTokenizers;

/**
 * @author Daniel Kurka
 * 
 */
@WithTokenizers({HomePlaceTokenizer.class, UIPlaceTokenizer.class, ScrollWidgetPlaceTokenizer.class, AboutPlaceTokenizer.class, ButtonPlaceTokenizer.class, AnimationDissolvePlaceTokenizer.class,
		AnimationFadePlaceTokenizer.class, AnimationFlipPlaceTokenizer.class, AnimationPlaceTokenizer.class, AnimationPopPlaceTokenizer.class, AnimationSlidePlaceTokenizer.class,
		AnimationSlideUpPlaceTokenizer.class, AnimationSwapPlaceTokenizer.class, ButtonBarPlaceTokenizer.class, ElementsPlaceTokenizer.class, FormsPlace.Tokenizer.class, PopupPlaceTokenizer.class,
		ProgressBarPlaceTokenizer.class, SearchBoxPlaceTokenizer.class, SliderPlaceTokenizer.class, TabBarPlaceTokenizer.class, PullToRefreshPlace.Tokenizer.class, AnimationCubePlace.Tokenizer.class,
		ProgressIndicatorPlace.Tokenizer.class, CarouselPlace.Tokenizer.class, GroupedCellListPlace.Tokenizer.class })
public interface AppPlaceHistoryMapper extends PlaceHistoryMapper {
}
