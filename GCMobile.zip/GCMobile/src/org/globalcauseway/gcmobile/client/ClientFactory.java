/*
 * Copyright 2010 Daniel Kurka
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.globalcauseway.gcmobile.client;

import org.globalcauseway.gcmobile.client.activities.AboutView;
import org.globalcauseway.gcmobile.client.activities.ShowCaseListView;
import org.globalcauseway.gcmobile.client.activities.UIView;
import org.globalcauseway.gcmobile.client.activities.animation.AnimationView;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationDoneView;
import org.globalcauseway.gcmobile.client.activities.button.ButtonView;
import org.globalcauseway.gcmobile.client.activities.buttonbar.ButtonBarView;
import org.globalcauseway.gcmobile.client.activities.carousel.CarouselView;
import org.globalcauseway.gcmobile.client.activities.elements.ElementsView;
import org.globalcauseway.gcmobile.client.activities.forms.FormsView;
import org.globalcauseway.gcmobile.client.activities.gcell.GroupedCellListView;
import org.globalcauseway.gcmobile.client.activities.popup.PopupView;
import org.globalcauseway.gcmobile.client.activities.progressbar.ProgressBarView;
import org.globalcauseway.gcmobile.client.activities.progressindicator.ProgressIndicatorView;
import org.globalcauseway.gcmobile.client.activities.pulltorefresh.PullToRefreshDisplay;
import org.globalcauseway.gcmobile.client.activities.scrollwidget.ScrollWidgetView;
import org.globalcauseway.gcmobile.client.activities.searchbox.SearchBoxView;
import org.globalcauseway.gcmobile.client.activities.slider.SliderView;
import org.globalcauseway.gcmobile.client.activities.tabbar.TabBarView;

import com.google.gwt.place.shared.PlaceController;
import com.google.web.bindery.event.shared.EventBus;

/**
 * @author Daniel Kurka
 * 
 */
public interface ClientFactory {
	public ShowCaseListView getHomeView();

	public EventBus getEventBus();

	public PlaceController getPlaceController();

	/**
	 * @return
	 */
	public UIView getUIView();

	public AboutView getAboutView();

	public AnimationView getAnimationView();

	public AnimationDoneView getAnimationDoneView();

	public ScrollWidgetView getScrollWidgetView();

	public ElementsView getElementsView();

	public ButtonBarView getButtonBarView();

	public SearchBoxView getSearchBoxView();

	public TabBarView getTabBarView();

	public ButtonView getButtonView();

	/**
	 * 
	 */
	public PopupView getPopupView();

	public ProgressBarView getProgressBarView();

	public SliderView getSliderView();

	public CarouselView getCarouselHorizontalView();

	public PullToRefreshDisplay getPullToRefreshDisplay();

	public ProgressIndicatorView getProgressIndicatorView();

	public FormsView getFormsView();

	public GroupedCellListView getGroupedCellListView();

}
