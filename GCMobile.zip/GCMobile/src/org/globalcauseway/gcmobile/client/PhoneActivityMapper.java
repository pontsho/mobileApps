/*
 * Copyright 2010 Daniel Kurka
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.globalcauseway.gcmobile.client;

import org.globalcauseway.gcmobile.client.activities.AboutActivity;
import org.globalcauseway.gcmobile.client.activities.AboutPlace;
import org.globalcauseway.gcmobile.client.activities.ShowCaseListActivity;
import org.globalcauseway.gcmobile.client.activities.UIActivity;
import org.globalcauseway.gcmobile.client.activities.UIPlace;
import org.globalcauseway.gcmobile.client.activities.animation.AnimationActivity;
import org.globalcauseway.gcmobile.client.activities.animation.AnimationPlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationDissolvePlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationDoneActivity;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationFadePlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationFlipPlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationPopPlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSlidePlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSlideUpPlace;
import org.globalcauseway.gcmobile.client.activities.animationdone.AnimationSwapPlace;
import org.globalcauseway.gcmobile.client.activities.button.ButtonActivity;
import org.globalcauseway.gcmobile.client.activities.button.ButtonPlace;
import org.globalcauseway.gcmobile.client.activities.buttonbar.ButtonBarActivity;
import org.globalcauseway.gcmobile.client.activities.buttonbar.ButtonBarPlace;
import org.globalcauseway.gcmobile.client.activities.carousel.CarouselActivity;
import org.globalcauseway.gcmobile.client.activities.carousel.CarouselPlace;
import org.globalcauseway.gcmobile.client.activities.elements.ElementsActivity;
import org.globalcauseway.gcmobile.client.activities.elements.ElementsPlace;
import org.globalcauseway.gcmobile.client.activities.forms.FormsActivity;
import org.globalcauseway.gcmobile.client.activities.forms.FormsPlace;
import org.globalcauseway.gcmobile.client.activities.gcell.GroupedCellListActivity;
import org.globalcauseway.gcmobile.client.activities.gcell.GroupedCellListPlace;
import org.globalcauseway.gcmobile.client.activities.popup.PopupActivity;
import org.globalcauseway.gcmobile.client.activities.popup.PopupPlace;
import org.globalcauseway.gcmobile.client.activities.progressbar.ProgressBarActivity;
import org.globalcauseway.gcmobile.client.activities.progressbar.ProgressBarPlace;
import org.globalcauseway.gcmobile.client.activities.progressindicator.ProgressIndicatorActivity;
import org.globalcauseway.gcmobile.client.activities.progressindicator.ProgressIndicatorPlace;
import org.globalcauseway.gcmobile.client.activities.pulltorefresh.PullToRefreshActivity;
import org.globalcauseway.gcmobile.client.activities.pulltorefresh.PullToRefreshPlace;
import org.globalcauseway.gcmobile.client.activities.scrollwidget.ScrollWidgetActivity;
import org.globalcauseway.gcmobile.client.activities.scrollwidget.ScrollWidgetPlace;
import org.globalcauseway.gcmobile.client.activities.searchbox.SearchBoxActivity;
import org.globalcauseway.gcmobile.client.activities.searchbox.SearchBoxPlace;
import org.globalcauseway.gcmobile.client.activities.slider.SliderActivity;
import org.globalcauseway.gcmobile.client.activities.slider.SliderPlace;
import org.globalcauseway.gcmobile.client.activities.tabbar.TabBarActivity;
import org.globalcauseway.gcmobile.client.activities.tabbar.TabBarPlace;
import org.globalcauseway.gcmobile.client.places.HomePlace;

import com.google.gwt.activity.shared.Activity;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.place.shared.Place;

/**
 * @author Daniel Kurka
 * 
 */
public class PhoneActivityMapper implements ActivityMapper {

	private final ClientFactory clientFactory;

	public PhoneActivityMapper(ClientFactory clientFactory) {
		this.clientFactory = clientFactory;
	}

	@Override
	public Activity getActivity(Place place) {
		if (place instanceof HomePlace) {
			return new ShowCaseListActivity(clientFactory);
		}

		if (place instanceof UIPlace) {
			return new UIActivity(clientFactory);
		}

		if (place instanceof AboutPlace) {
			return new AboutActivity(clientFactory);
		}

		if (place instanceof AnimationPlace) {
			return new AnimationActivity(clientFactory);
		}

		if (place instanceof ScrollWidgetPlace) {
			return new ScrollWidgetActivity(clientFactory);
		}

		if (place instanceof ElementsPlace) {
			return new ElementsActivity(clientFactory);
		}

		if (place instanceof FormsPlace) {
			return new FormsActivity(clientFactory);
		}

		if (place instanceof ButtonBarPlace) {
			return new ButtonBarActivity(clientFactory);
		}

		if (place instanceof SearchBoxPlace) {
			return new SearchBoxActivity(clientFactory);
		}

		if (place instanceof TabBarPlace) {
			return new TabBarActivity(clientFactory);
		}

		if (place instanceof ButtonPlace) {
			return new ButtonActivity(clientFactory);
		}

		if (place instanceof PopupPlace) {
			return new PopupActivity(clientFactory);
		}

		if (place instanceof ProgressBarPlace) {
			return new ProgressBarActivity(clientFactory);
		}

		if (place instanceof ProgressIndicatorPlace) {
			return new ProgressIndicatorActivity(clientFactory);
		}

		if (place instanceof SliderPlace) {
			return new SliderActivity(clientFactory);
		}
		if (place instanceof PullToRefreshPlace) {
			return new PullToRefreshActivity(clientFactory);
		}

		if (place instanceof CarouselPlace) {
			return new CarouselActivity(clientFactory);
		}

		if (place instanceof GroupedCellListPlace) {
			return new GroupedCellListActivity(clientFactory);
		}

		if (place instanceof AnimationSlidePlace || place instanceof AnimationSlideUpPlace || place instanceof AnimationDissolvePlace || place instanceof AnimationFadePlace
				|| place instanceof AnimationFlipPlace || place instanceof AnimationPopPlace || place instanceof AnimationSwapPlace || place instanceof AnimationSwapPlace) {
			return new AnimationDoneActivity(clientFactory);
		}
		return new ShowCaseListActivity(clientFactory);
	}
}
